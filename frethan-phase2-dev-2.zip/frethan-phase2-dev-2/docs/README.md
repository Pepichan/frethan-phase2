# 📁 Project Documents
This folder contains documentation files for the Frethan Project.
