#!/bin/bash
echo "��� Testing Environment..."
curl -s http://localhost:5000/api/health >/dev/null && echo "✅ Backend OK" || echo "❌ Backend FAIL"
curl -s http://localhost:5174 >/dev/null && echo "✅ Frontend OK" || echo "❌ Frontend FAIL"
echo "Backend:  http://localhost:5000"
echo "Frontend: http://localhost:5174"
