 import {
  createSupplier,
  getSuppliers,
  updateSupplierStatus
} from "../rupak-frethanApi";

// Your friend only needs these 3 functions in the UI

export async function addNewSupplier(formData) {
  return await createSupplier(formData);
}

export async function fetchAllSuppliers() {
  return await getSuppliers();
}

export async function verifySupplier(id) {
  return await updateSupplierStatus(id, "verified");
}
