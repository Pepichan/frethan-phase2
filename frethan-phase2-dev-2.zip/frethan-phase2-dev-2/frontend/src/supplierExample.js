import {
  addNewSupplier,
  fetchAllSuppliers,
  verifySupplier
} from "./services/supplierService";

// Example 1: Add supplier
export async function handleAddSupplier() {
  const supplier = {
    name: "Test Company",
    email: "test@example.com",
    phone: "0400 000 000",
    country: "Australia"
  };

  const result = await addNewSupplier(supplier);
  console.log("Supplier Added:", result);
}

// Example 2: Show supplier list
export async function handleGetSuppliers() {
  const list = await fetchAllSuppliers();
  console.log("Supplier List:", list);
}

// Example 3: Update supplier verification
export async function handleVerifySupplier() {
  const result = await verifySupplier(1); // verify supplier with ID 1
  console.log("Supplier Verified:", result);
}
