export default function Home() {
    return (
      <div
        style={{
          background: '#1a1a1a',
          padding: '2rem',
          borderRadius: '12px',
          border: '1px solid #333',
        }}
      >
        <h1 style={{ marginBottom: '0.8rem' }}>Welcome</h1>
        <p style={{ opacity: 0.75 }}>
          This is the Frethan Procurement platform prototype.
        </p>
      </div>
    );
  }
  