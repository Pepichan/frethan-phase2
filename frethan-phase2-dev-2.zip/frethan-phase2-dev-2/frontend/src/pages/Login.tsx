function Login() {
    return (
      <div>
        <h1>Login</h1>
        <p>This is where users will sign in to the system.</p>
      </div>
    );
  }
  
  export default Login;
  