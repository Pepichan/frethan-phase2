function Dashboard() {
    return (
      <div>
        <h1>Dashboard</h1>
        <p>Here we will show supplier & RFQ information.</p>
      </div>
    );
  }
  
  export default Dashboard;
  