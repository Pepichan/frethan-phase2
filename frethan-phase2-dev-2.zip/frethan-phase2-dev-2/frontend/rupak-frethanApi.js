// Base URL of your backend
const API_BASE = "http://localhost:4000/api";

// -------------------------------
// Create a new supplier
// -------------------------------
export async function createSupplier(data) {
  const response = await fetch(`${API_BASE}/suppliers`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  });

  return response.json(); // returns created supplier
}

// -------------------------------
// Get all suppliers
// -------------------------------
export async function getSuppliers() {
  const response = await fetch(`${API_BASE}/suppliers`);
  return response.json();
}

// -------------------------------
// Update supplier verification status
// Ex: updateSupplierStatus(1, "verified")
// -------------------------------
export async function updateSupplierStatus(id, status) {
  const response = await fetch(`${API_BASE}/suppliers/${id}/status`, {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ status }),
  });

  return response.json();
}
