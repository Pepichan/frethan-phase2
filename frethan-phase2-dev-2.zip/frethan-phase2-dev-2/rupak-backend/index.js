const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 4000;

app.use(cors());
app.use(express.json());

let suppliers = [];
let complianceChecks = [];
let shipments = [];
let disputes = [];

let supplierId = 1;
let complianceId = 1;
let shipmentId = 1;
let disputeId = 1;

app.get("/", (req, res) => {
  res.json({ message: "Rupak backend is running" });
});

// SUPPLIERS
app.post("/api/suppliers", (req, res) => {
  const { name, email, phone, country } = req.body;
  if (!name) return res.status(400).json({ error: "Name is required" });

  const supplier = {
    id: supplierId++,
    name,
    email: email || "",
    phone: phone || "",
    country: country || "",
    status: "pending",
    createdAt: new Date()
  };

  suppliers.push(supplier);
  res.status(201).json(supplier);
});

app.get("/api/suppliers", (req, res) => {
  res.json(suppliers);
});

app.patch("/api/suppliers/:id/status", (req, res) => {
  const id = Number(req.params.id);
  const { status } = req.body;
  const supplier = suppliers.find((s) => s.id === id);

  if (!supplier) return res.status(404).json({ error: "Supplier not found" });
  if (!["pending", "verified", "rejected"].includes(status)) {
    return res.status(400).json({ error: "Invalid status" });
  }

  supplier.status = status;
  res.json(supplier);
});

// COMPLIANCE
app.post("/api/compliance", (req, res) => {
  const { supplierId: sId, type, notes } = req.body;
  if (!sId || !type) {
    return res.status(400).json({ error: "supplierId and type are required" });
  }

  const check = {
    id: complianceId++,
    supplierId: sId,
    type,
    status: "pending",
    notes: notes || "",
    createdAt: new Date()
  };

  complianceChecks.push(check);
  res.status(201).json(check);
});

app.get("/api/compliance", (req, res) => {
  const { supplierId } = req.query;
  let result = complianceChecks;
  if (supplierId) {
    result = result.filter((c) => String(c.supplierId) === String(supplierId));
  }
  res.json(result);
});

app.patch("/api/compliance/:id/status", (req, res) => {
  const id = Number(req.params.id);
  const { status, notes } = req.body;

  const check = complianceChecks.find((c) => c.id === id);
  if (!check) return res.status(404).json({ error: "Compliance check not found" });
  if (status && !["pending", "pass", "fail"].includes(status)) {
    return res.status(400).json({ error: "Invalid status" });
  }

  if (status) check.status = status;
  if (notes) check.notes = notes;
  res.json(check);
});

// SHIPMENTS
app.post("/api/shipments", (req, res) => {
  const { trackingNumber, supplierId: sId, origin, destination } = req.body;
  if (!trackingNumber) {
    return res.status(400).json({ error: "trackingNumber is required" });
  }

  const shipment = {
    id: shipmentId++,
    trackingNumber,
    supplierId: sId || null,
    origin: origin || "",
    destination: destination || "",
    status: "created",
    lastLocation: origin || "",
    eta: null,
    createdAt: new Date()
  };

  shipments.push(shipment);
  res.status(201).json(shipment);
});

app.get("/api/shipments/track/:trackingNumber", (req, res) => {
  const { trackingNumber } = req.params;
  const shipment = shipments.find((sh) => sh.trackingNumber === trackingNumber);
  if (!shipment) return res.status(404).json({ error: "Shipment not found" });
  res.json(shipment);
});

app.patch("/api/shipments/:id/status", (req, res) => {
  const id = Number(req.params.id);
  const { status, lastLocation, eta } = req.body;

  const shipment = shipments.find((sh) => sh.id === id);
  if (!shipment) return res.status(404).json({ error: "Shipment not found" });
  if (status && !["created", "in_transit", "delivered", "cancelled"].includes(status)) {
    return res.status(400).json({ error: "Invalid status" });
  }

  if (status) shipment.status = status;
  if (lastLocation) shipment.lastLocation = lastLocation;
  if (eta) shipment.eta = eta;
  res.json(shipment);
});

// DISPUTES
app.post("/api/disputes", (req, res) => {
  const { shipmentId: shId, raisedBy, reason } = req.body;
  if (!shId || !raisedBy || !reason) {
    return res
      .status(400)
      .json({ error: "shipmentId, raisedBy and reason are required" });
  }

  const dispute = {
    id: disputeId++,
    shipmentId: shId,
    raisedBy,
    reason,
    status: "open",
    resolutionNotes: "",
    createdAt: new Date()
  };

  disputes.push(dispute);
  res.status(201).json(dispute);
});

app.get("/api/disputes", (req, res) => {
  const { shipmentId } = req.query;
  let result = disputes;
  if (shipmentId) {
    result = result.filter((d) => String(d.shipmentId) === String(shipmentId));
  }
  res.json(result);
});

app.patch("/api/disputes/:id/status", (req, res) => {
  const id = Number(req.params.id);
  const { status, resolutionNotes } = req.body;

  const dispute = disputes.find((d) => d.id === id);
  if (!dispute) return res.status(404).json({ error: "Dispute not found" });
  if (status && !["open", "in_review", "resolved", "rejected"].includes(status)) {
    return res.status(400).json({ error: "Invalid status" });
  }

  if (status) dispute.status = status;
  if (resolutionNotes) dispute.resolutionNotes = resolutionNotes;
  res.json(dispute);
});

app.listen(PORT, () => {
  console.log(`Rupak backend running on http://localhost:${PORT}`);
});
